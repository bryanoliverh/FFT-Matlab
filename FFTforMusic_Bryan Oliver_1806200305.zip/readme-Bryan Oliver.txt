Bryan Oliver.
1806200305.
Teknik Komputer.
Proyek FFT Analysis for Music.

Fungsi yang tersedia:
1. Analisa Spektrum.
Berfungsi dalam menganalisa komponen sinyal suara.
2. Adjustment Accuracy.
Menampilkan fungsi grafik spektrum dengan fungsi waktu yang diadjust untuk ketelitian.
2. Power Spectral Density.
Fungsi untuk mengubah sinyal suara dalam waktu menjadi frekuensi. Sehingga 
dari axis X dan Y berupa waktu dan amplitudo menjadi frekuensi dan power.
3. Save as Picture
Grafik dikonversi menjadi file gambar (sehingga bisa langsung disave).
Pada proyek ini menjadi .jpg, contohnya pada gambar di clip.
4. Music Menu
akan membuka suatu window untuk memasukkan file mp3 atau format lainnya (disesuaikan pada kode).
